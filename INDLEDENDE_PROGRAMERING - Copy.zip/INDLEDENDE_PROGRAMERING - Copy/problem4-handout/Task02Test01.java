// Do not modify this file!

class Task02Test01 {
    public static void main(String[] args) {
        var titlesOpinions = new String[][] { {"Sisu", "rad"},
                                             {"The Thing (1982)", "wicked"},
                                             {"The Thing (2011)", "rotten"},
                                             {"American Sniper", "legit"},
                                             {"Dune (1984)", "meh"},
                                             {"Dune (2021)", "Wicked"},
                                             {"Galaxy Quest", "rad!"},
                                             {"Cinderella", ""},
                                             {"Snow White (1937)", null} };

        TestUtils.tryCreateMovie(titlesOpinions);
    }
}
