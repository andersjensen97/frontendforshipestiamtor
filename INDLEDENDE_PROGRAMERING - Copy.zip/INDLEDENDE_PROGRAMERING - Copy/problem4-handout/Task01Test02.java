// Do not modify this file!

class Task01Test02 {
    public static void main(String[] args) {
        var titles = new String[] { "The Thing (1982)",
                                    "The Thing (2011)",
                                    "The Room",
                                    "American Sniper",
                                    "Dune (1984)",
                                    "Dune (2021)",
                                    "Galaxy Quest",
                                    "",
                                    " Cinderella",
                                    "Snow White (1937) ",
                                    null,
                                    "John  Wick: Chapter 4" };

        TestUtils.trySetTitle(titles);
    }
}
