// Do not modify this file!

class Task02Test02 {
    public static void main(String[] args) {
        var opinions = new String[] { "rad",
                                     "rad",
                                     "rotten",
                                     "meh",
                                     "wicked",
                                     "legit",
                                     "-23",
                                     "  ",
                                     "22",
                                     "a",
                                     "bcd",
                                     "0011",
                                     null  };

        TestUtils.trySetOpinion(opinions);
    }
}
