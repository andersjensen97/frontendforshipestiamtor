// Do not modify this file!

class Task02Test01 {
    public static void main(String[] args) {
        var aliens = new Alien[] {
            new Gorn("Grunt", true),
            new Gorn("Bleurgh", false),
            new Gorn("Pernille", false)
        };

        TestUtils.displayAliens(aliens);
    }
}
