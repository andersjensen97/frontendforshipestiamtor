// Do not modify this file!

class Task02Test02 {
    public static void main(String[] args) {
        TestUtils.checkPrivateFields(Gorn.class);
    }
}
