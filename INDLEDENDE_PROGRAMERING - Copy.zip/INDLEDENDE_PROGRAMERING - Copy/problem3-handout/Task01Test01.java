// Do not modify this file!

class Task01Test01 {
    public static void main(String[] args) {
        var aliens = new Alien[] {
            new Alien("Anders Andersen", "Human", "Earth"),
            new Alien("Tokal", "Romulan", "Romulus"),
            new Alien("Syna", "Klingon", "Klinzhai")
        };

        TestUtils.displayAliens(aliens);
    }
}
