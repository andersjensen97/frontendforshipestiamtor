// Do not modify this file!

class Task03Test01 {
    public static void main(String[] args) {
        var aliens = new Alien[] {
            new Cardassian("Crony Osel", "diamond"),
            new Cardassian("Mila Lasar", "emerald"),
            new Cardassian("Kora Dara", "ruby")
        };

        TestUtils.displayAliens(aliens);
    }
}
