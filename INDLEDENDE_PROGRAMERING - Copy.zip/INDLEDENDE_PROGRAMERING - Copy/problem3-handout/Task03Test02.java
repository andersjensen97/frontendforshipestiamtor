// Do not modify this file!

class Task03Test02 {
    public static void main(String[] args) {
        TestUtils.checkPrivateFields(Cardassian.class);
    }
}
