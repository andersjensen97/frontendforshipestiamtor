// Do not modify this file!

class Task01Test02 {
    public static void main(String[] args) {
        TestUtils.checkPrivateFields(Alien.class);
    }
}
