PLEASE DO NOT EDIT THE FILES IN THIS DIRECTORY!

This directory contains the configuration files for the program that calculates
a grade for your lab submission.

If you change these files, the grading may fail, or give incorrect results
ON YOUR COMPUTER (but it will keep working correctly on Autolab).
